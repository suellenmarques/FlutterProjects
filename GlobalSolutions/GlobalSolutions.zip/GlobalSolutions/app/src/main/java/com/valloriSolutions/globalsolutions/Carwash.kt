package com.valloriSolutions.globalsolutions

data class Carwash(
    var nome: String,
    var endereco: String,
    var valor: String,
    var horario: String
)
