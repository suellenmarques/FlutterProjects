package com.valloriSolutions.globalsolutions

//@Dao
interface SchedulingDAO {
}