package com.valloriSolutions.globalsolutions

data class Car(
    var modelo: String,
    var ano: String,
    var placa: String,
    var proprietario: String
)
